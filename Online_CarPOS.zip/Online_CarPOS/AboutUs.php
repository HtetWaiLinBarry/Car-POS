<?php include('header.php') ?>

<!DOCTYPE html>
<html>
<head>
	<title>About Us</title>
</head>
<body>
<table>
	IT'S ALL ABOUT US
	<tr>
		<td>
			WHAT ARE WE?
		</td>
		<td>
			We are both a vehicle sales and trading company where our customers will be able to purchase vehicles as easy as possible.
		</td>
	</tr>
	<tr>
		<td>
			HOW DO WE WORK?
		</td>
		<td>
			It's all about trust. We trust our customers and our customers trust us.
		</td>
	</tr>
	<tr>
		<td>
			WHAT CAN WE OFFER?
		</td>
		<td>
			A whole lot of vehicles ranging from agricultural uses to modern vehicles, even the ones with autopilot if you may ask.
		</td>
	</tr>
	<tr>
		<td>
			WHAT
		</td>
		<td>
			WE ARE DOING NOW IS TO FIND NEW WAYS TO BUY AND SELL VEHICLES EFFORTLESSLY.
		</td>
	</tr>
	<tr>
		<td>
			REST
		</td>
		<td>
			ASSURED BECAUSE WE ARE DOING THE BEST WE CAN!
		</td>
	</tr>
</table>
</body>
</html>